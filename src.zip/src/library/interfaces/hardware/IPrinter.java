package library.interfaces.hardware;

public interface IPrinter {
	
	public void print(String printData);
	
}
