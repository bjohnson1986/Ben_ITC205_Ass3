package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class LoanTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testLoan() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testCommit() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testComplete() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testIsOverDue() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testCheckOverDue() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetBorrower() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetBook() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetID() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testIsCurrent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testObject() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetClass() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testHashCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testEquals() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testClone() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testToString() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testNotify() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testNotifyAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testWaitLong() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testWaitLongInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testWait() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testFinalize() {
		fail("Not yet implemented"); // TODO
	}

}
